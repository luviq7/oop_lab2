// функція повертає число, яке утворене циклічним побітовим зсувом вліво
// заданого числа на задану кількість бітів
#pragma once
unsigned int ShiftLeft(unsigned int uiNumber, unsigned int uiBits);